import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;

class ApiFailure implements Exception {
  final String message;
  final int status;
  ApiFailure(this.message,this.status);
  @override String toString()=>message;
}

class ApiClient {
  String baseUrl;
  String? token;
  ApiClient(this.baseUrl,{this.token});
  Uri uri(String path,[Map<String,String>? params]) =>
    Uri.parse('${baseUrl.replaceAll(RegExp(r'/$'),'')}/api/v1/$path').replace(queryParameters:params);
  Map<String,String> headers({bool write=false}) => {
    if(token!=null) 'Authorization':'Bearer $token',
    'Content-Type':'application/json',
    if(write) 'Idempotency-Key':_idempotencyKey(),
  };
  String _idempotencyKey() {
    final r=Random.secure();
    return List.generate(32,(_)=>r.nextInt(256).toRadixString(16).padLeft(2,'0')).join();
  }
  Future<dynamic> _parse(http.Response r) async {
    final body=jsonDecode(utf8.decode(r.bodyBytes));
    if(r.statusCode>=400) throw ApiFailure(body is Map ? (body['error']?.toString() ?? 'فشل الطلب') : 'فشل الطلب',r.statusCode);
    return body;
  }
  Future<List<Map<String,dynamic>>> list(String path,[Map<String,String>? params]) async {
    final response=await http.get(uri(path,params),headers:headers()).timeout(const Duration(seconds:12));
    final decoded=await _parse(response) as List<dynamic>;
    return decoded.map((x)=>Map<String,dynamic>.from(x as Map)).toList();
  }
  Future<Map<String,dynamic>> get(String path,[Map<String,String>? params]) async {
    final response=await http.get(uri(path,params),headers:headers()).timeout(const Duration(seconds:12));
    return Map<String,dynamic>.from(await _parse(response) as Map);
  }
  Future<Map<String,dynamic>> post(String path,Map<String,dynamic> body,{bool idempotent=true}) async {
    final response=await http.post(uri(path),headers:headers(write:idempotent),body:jsonEncode(body))
      .timeout(const Duration(seconds:20));
    return Map<String,dynamic>.from(await _parse(response) as Map);
  }
}
