# Kasher Local API — development reference

Base URL: `http://127.0.0.1:8787/api/v1`. The HTTP transport is currently **not encrypted**; do not expose this service to the public internet or an untrusted LAN.

## Authentication

`POST /auth/login`: JSON `{ "tenant_id": "...", "username": "admin", "password": "..." }`. Returns token and scope IDs. Send `Authorization: Bearer <token>` for authenticated endpoints. `POST /auth/logout` revokes the token; `GET /me` returns the active principal. `/health` is outside `/api/v1` and needs no authentication.

## Reads

| Route | Description |
| --- | --- |
| `GET /branches` | Authorized branches |
| `GET /products?q=...` | Product catalog |
| `GET /customers` | Customers |
| `GET /suppliers` | Suppliers |
| `GET /stock?branch_id=...` | Branch stock |
| `GET /documents?branch_id=...` | Transaction documents |
| `GET /documents/<id>` | Single document |
| `GET /dashboard?branch_id=...` | Operational metrics |
| `GET /audit?branch_id=...` | Audit history (authorized roles) |
| `GET /sync/outbox?branch_id=...` | Locally queued events (not cloud synchronization) |

## Writes

All operational write endpoints accept JSON, Bearer authentication, and an **`Idempotency-Key` header of 16–128 characters**. Reuse exactly the same key and JSON payload on retries: a new key is a new operation. Different requests reusing a key are rejected.

| POST path | Command |
| --- | --- |
| `/products` | `create_product` |
| `/customers` | `create_customer` |
| `/suppliers` | `create_supplier` |
| `/branches` | `create_branch` |
| `/purchases` | `purchase` |
| `/sales` | `sale` |
| `/sales/returns` | `sale_return` |
| `/purchases/returns` | `purchase_return` |
| `/customers/receipts` | `customer_receipt` |
| `/suppliers/payments` | `supplier_payment` |
| `/expenses` | `expense` |
| `/inventory/adjustments` | `adjust_stock` |
| `/inventory/preparations` | `prepare` |

Example sale: 

```json
{
  "branch_id": "<branch UUID>",
  "customer_id": "<optional customer UUID>",
  "lines": [{"product_id": "<product UUID>", "qty_milli": 1000}],
  "payments": [{"method": "cash", "amount_minor": 2500}]
}
```

Money is expressed as integer Egyptian piasters (`amount_minor`); stock quantity is an integer in thousandths of the base unit (`qty_milli`). See domain validation and tests under `server/lib/src/engine.dart` and `server/test/` for exact accepted commands and invariants.

This is an evolving developer API, not yet a versioned external integration contract.
