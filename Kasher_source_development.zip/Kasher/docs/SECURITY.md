# Security boundaries and deployment blockers

This code is a development baseline and **must not be deployed over the public internet**.

- The branch server defaults to `127.0.0.1`, which prevents direct LAN access. Binding to `0.0.0.0` is allowed for controlled development networks but currently uses unencrypted HTTP.
- Authentication: salted PBKDF2-HMAC-SHA256 password hashing; opaque session tokens are stored hashed in SQLite; tokens expire after 12 hours; roles and tenant/branch scopes are checked in domain operations.
- SQLite is owned by the local server. Never share its database file over SMB; clients connect through the server API.
- Sensitive updates are handled inside SQLite transactions, with idempotency records and audit events. Secrets, private backups and SQLite files must never be committed.
- Configure firewall rules and restrict physical/database access before any local pilot.
- **Outstanding before production**: TLS with trusted certificates, secure device pairing, session and login rate limiting, credential recovery, full role-action matrix test coverage, encryption at rest/backups, documented retention/restore controls, OS permissions and malware hardening, privacy review, penetration testing, signing and secure update mechanism.
- Offline functionality means the **branch host** continues to operate without internet. A disconnected remote cashier is **not** guaranteed to finalize sales safely; do not assume offline Android device writes are enabled.
- Regulatory tax receipts and payment processing are not implemented. Recorded card/wallet entries do not initiate banking transactions.
